//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GVRgui.rc
//
#define IDOK2                           2
#define IDOK3                           3
#define IDOK4                           4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GVRGUI_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     131
#define IDB_BITMAP4                     132
#define IDB_BITMAP5                     133
#define IDB_BITMAP6                     134
#define IDB_BITMAP7                     135
#define IDB_BITMAP8                     136
#define IDB_BITMAP9                     137
#define IDD_MESSAGE_DIALOG              140
#define IDI_ICON5                       141
#define IDI_ICON6                       142
#define IDI_ICON7                       143
#define IDI_ICON8                       144
#define IDI_ICON9                       145
#define IDD_TEST_DIALOG                 150
#define IDB_BITMAP10                    151
#define IDB_BITMAP11                    152
#define IDB_BITMAP12                    153
#define IDB_BITMAP13                    154
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_STATUS                      1003
#define IDC_SERIAL                      1004
#define IDC_PRINTER                     1005
#define IDC_TIME                        1006
#define IDC_STATION                     1007
#define IDC_CP3105                      1008
#define IDC_RESULT                      1011
#define IDC_STOP                        1012
#define IDC_CANCEL                      1013
#define IDC_TIME2                       1013
#define IDC_AVERAGE                     1013
#define IDC_MESSAGE                     1014
#define IDC_ALERT                       1015
#define IDC_PASS                        1016
#define IDC_FAIL                        1017
#define IDC_PROMPT                      1018
#define IDC_ERROR                       1019
#define IDC_SCAN                        1020
#define IDC_DOSCAN                      1021
#define IDC_GPASS                       1022
#define IDC_RFAIL                       1023
#define IDC_ADMIN                       1024
#define ID_CAN                          1025
#define IDC_PICTURE2                    1033
#define IDC_PICTURE1                    1034
#define IDC_PICTURE3                    1036
#define IDC_PICTURE4                    1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

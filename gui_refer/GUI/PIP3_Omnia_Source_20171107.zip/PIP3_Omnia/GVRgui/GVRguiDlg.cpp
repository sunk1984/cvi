// GVRguiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GVRgui.h"
#include "GVRguiDlg.h"
#include "Message.h"
#include "CTestMessage.h"
#include "CPort.h"
#include "CConsole.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//Supress warnings
#pragma warning(disable : 4800)	//Int to bool
#pragma warning(disable : 4996)	//Scanf
#pragma warning(disable : 4267)
#pragma warning(disable : 4309)

#define VERSION 0x20171107

#define UUT_TYPE_A001	0
#define UUT_TYPE_A002	1

#define TEST_IDLE		0
#define TEST_RUN		1
#define TEST_STOP		2
#define TEST_ERROR		3
#define TEST_FAIL		4
#define TEST_PASS		5
#define TEST_EXIT		6
#define TEST_FAULT		7
#define TEST_SERIAL		8
#define TEST_ADMIN		9

#define CONTROLS_OFF	0
#define CONTROLS_ON		1

#define QUICK_WAIT		100
#define WAIT_1S			1000
#define WAIT_2S			2000
#define WAIT_6S			6000
#define WAIT_15S		15000
#define WAIT_30S		30000
#define WAIT_45S		45000
#define WAIT_60S		60000
#define WAIT_1000S		1000000

#define CONSOLE		1
#define NO_CONSOLE	0
#define SCREEN		1
#define NO_SCREEN	0
#define PRINT		1
#define NO_PRINT	0

enum test {
TEST_TYPE=1,	
TEST_POWER,		//6.1
TEST_VOLTAGE,	//6.2&6.3
TEST_CURRENT,	//6.4.5
PRG_CP2105,		//5.3
TEST_USB_HUB,	//6.4.1
TEST_DUART,		//6.4.2
TEST_USB,		//6.4.3
TEST_USB_PWR,	//6.4.4
BNA_PORT,		//6.5
BNA_VAULT,		//6.6
TRIND_TEST,		//6.7
TEST_CP2105,	//6.8
TEST_PWM,		//6.9 (A002 only)
TEST_BACKLIGHT,	//6.10
TEST_RGB,		//6.11(A001 only)
TEST_LVDS,		//6.12(A002 only)
TEST_AUDIO,		//6.13
TEST_BEEP,		//6.14
TEST_LEDS		//6.15
};

#define BUFFER_SIZE	5000

bool m_bTest1=true;		//6.2&6.3 Voltage
bool m_bTest2=true;		//6.4.5   Over current
bool m_bTest3=true;		//5.3     Program CP2105
bool m_bTest4=true;		//6.4.1   USB enumeration 
bool m_bTest5=true;		//6.4.2   DUART
bool m_bTest6=true;		//6.4.3   USB R/W
bool m_bTest7=true;		//6.4.4   USB power
bool m_bTest8=true;		//6.5     BNA port
bool m_bTest9=true;		//6.6     BNA Vault
bool m_bTest10=true;	//6.7     TRIND Port
bool m_bTest11=true;	//6.8     CP2105
bool m_bTest12=true;	//6.9     PWM (A002 only)
bool m_bTest13=true;	//6.10    Backlight
bool m_bTest14=true;	//6.11    RGB
bool m_bTest15=true;	//6.12    LVDS
bool m_bTest16=true;	//6.13....Audio
bool m_bTest17=true;	//6.14....Beeper
bool m_bTest18=true;	//6.15    LED

CPort* ComPort=new CPort();
CPort* Printer=new CPort();
CConsole* Console=new CConsole(80,200);

bool	m_bTestRunning=false;
bool	m_bUUTportOpen=false;
bool	m_bPrinterOpen=false;
bool	m_bPrintPortOpen=false;
int		m_iStatus=TEST_IDLE;

int		m_iComPort=84;
int		m_iPrinter=1;
char	m_czStation[5];
int		m_iUUTtype=UUT_TYPE_A001;

char	m_czUUTserial[25]="";

char	m_czRawSerial[25]="";			//20170926 - Save the raw serial
char	m_czSetType[20]="A001\r\n";

char	m_czDispBuffer[BUFFER_SIZE];	//20170815 - Was 2000
char	m_czTapeBuffer[BUFFER_SIZE];	//20170815 - Was 2000
char	m_czPrintBuffer[BUFFER_SIZE];	//20170815 - Was 2000
char	m_czVersion[25];
bool	m_bTimer;			//Timer on
int		m_iAbsSec;			//Total seconds
int		m_iAvSec;
int		m_iSec;				
int		m_iMin;
int		m_iTested;
char	m_czIsoTime[20];	//ISO timestamp
char	m_czTime[20];		//Time of day
char	m_czAsciiTime[20];	//Test time
DWORD	m_dwTime=0;			//Current tick
char	m_czTimeStamp[20];	//Timestamp  mm:ss:ms
bool	m_bCP2105=true;		//Default to programming EEPROM - 20170830
bool	m_bCPLD=false;
bool	m_bQualcomm=true;
bool	m_bContFail=true;
bool	m_bCOnChange=false;		//Configuration changed
bool	m_bConfEnable=false;	//Allow changes to the configuration
int		m_iCounts[8];			//Past counts
char	m_czResultLog[100]="";
char	m_czTapeLog[100]="";



// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CGVRguiDlg dialog




CGVRguiDlg::CGVRguiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGVRguiDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGVRguiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CGVRguiDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CGVRguiDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDOK2, &CGVRguiDlg::OnBnClickedOk2)
	ON_BN_CLICKED(IDOK3, &CGVRguiDlg::OnBnClickedOk3)
	ON_BN_CLICKED(IDC_RADIO1, &CGVRguiDlg::OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO3, &CGVRguiDlg::OnBnClickedRadio3)
	ON_BN_CLICKED(IDOK4, &CGVRguiDlg::OnBnClickedOk4)
	ON_BN_CLICKED(IDC_CP3105, &CGVRguiDlg::OnBnClickedCp2105)
	ON_EN_CHANGE(IDC_SERIAL, &CGVRguiDlg::OnEnChangeSerial)
	ON_EN_CHANGE(IDC_PRINTER, &CGVRguiDlg::OnEnChangePrinter)
	ON_EN_CHANGE(IDC_STATION, &CGVRguiDlg::OnEnChangeStation)
	ON_BN_CLICKED(IDC_STOP, &CGVRguiDlg::OnBnClickedStop)
END_MESSAGE_MAP()


// CGVRguiDlg message handlers

BOOL CGVRguiDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CClientDC dc(this);
	CButton *pMessage=new CButton;
	CFont font;
	font.CreatePointFont(400,_T("Consolas"),&dc);
	
	pMessage=reinterpret_cast<CButton*>(GetDlgItem(IDC_RESULT));	
	pMessage->SetFont(&font);

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//Kill the exit button
	CMenu* pSM=GetSystemMenu(FALSE);
	if(pSM) pSM->EnableMenuItem(SC_CLOSE,MF_BYCOMMAND|MF_GRAYED|MF_DISABLED);
	//Test for and create a directory for the ini
	if(GetFileAttributes(_T("./ini/"))==INVALID_FILE_ATTRIBUTES) CreateDirectory(_T("./ini"),NULL);
	//Test for and create a directory for the logd
	if(GetFileAttributes(_T("./log/"))==INVALID_FILE_ATTRIBUTES) CreateDirectory(_T("./log"),NULL);
	//Test for and create a sub directory for the test logs
	if(GetFileAttributes(_T("./log/result"))==INVALID_FILE_ATTRIBUTES) CreateDirectory(_T("./log/result"),NULL);
	//Test for and create a sub directory for the tape logs - 20170328
	if(GetFileAttributes(_T("./log/tape"))==INVALID_FILE_ATTRIBUTES) CreateDirectory(_T("./log/tape"),NULL);
	//Start the console
	Console->Show(_T("Debug Console "));	
	Console->SetPosition(0,200);
	sprintf(m_czVersion,"%08X",VERSION);
	Console->Write(CONSOLE_COLOR_WHITE,"PIP3 Omnia GUI (C) 2017 VSI\nVersion: ");
	Console->Write(CONSOLE_COLOR_CYAN,&m_czVersion[0]);
	Console->Write(CONSOLE_COLOR_WHITE,"\n\n\n");
	//Set up dialog
	static_cast<CEdit*>(GetDlgItem(IDC_SERIAL))->LimitText(4);
	static_cast<CEdit*>(GetDlgItem(IDC_PRINTER))->LimitText(4);
	static_cast<CEdit*>(GetDlgItem(IDC_STATION))->LimitText(3);
	//Read the config
	Console->Write(CONSOLE_COLOR_WHITE,"Reading INI file\n");
	GetINI();
	//Misc setup
	ClearTime();
	SetTimer(1,1000,NULL);
	for(int i=0;i<8;i++) m_iCounts[i]=0;	//Clear past counts
	m_iAvSec=0;
	m_iTested=0;
	//Check for morons
	if(checkAdmin()==false)
	{
		m_iStatus=TEST_ADMIN;
		UpdateStatusUser();
	}
	else Console->Write(CONSOLE_COLOR_WHITE,"GUI Ready!\n\n");

//--DEBUG----------------------------------------------------------------------------------
//	bool result=true;
//	result=DoMessage(PROG_CP2105,"CP2105 Programming","Please program the CP2105, and Click PASS or FAIL");
//	result=DoMessage(CHECK_RGB,"Test message II","Please do something cool, and\n Click PASS or FAIL");
//	result=DoMessage(CHECK_LVDS,"Test message III","Please do something cool, and\n Click PASS or FAIL");
//	result=DoMessage(CHECK_BEEP,"Test Buzzer","If you heard beeps at three different levels,\n please click PASS or FAIL");
//-----------------------------------------------------------------------------------------
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGVRguiDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGVRguiDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGVRguiDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


//=====================================================================================
//===================================[ Clear Time ]====================================
//=====================================================================================
void CGVRguiDlg::ClearTime(void)
{
	m_bTimer=false;
	m_czTime[0]=0;
	m_iAbsSec=0;
	m_iSec=0;
	m_iMin=0;
	sprintf(&m_czAsciiTime[0],"00:00");
	sprintf(&m_czTimeStamp[0],"00:00.00 ");
	m_dwTime=GetTickCount();
}

//=====================================================================================
//===================================[ Do Events ]=====================================
//=====================================================================================
//Keep the user interface warm
void CGVRguiDlg::doEvents(void)
{
	MSG msg;

	while(PeekMessage(&msg,NULL,NULL,NULL,PM_REMOVE))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

//=====================================================================================
//===================================[ Do Wait ]=======================================
//=====================================================================================
//Sleep, but keep the GUI warm
void CGVRguiDlg::doWait(DWORD Delay)
{
	DWORD target;

	target=GetTickCount()+Delay;
	while(GetTickCount()<target) doEvents();
}

//=====================================================================================
//===================================[ Get Timestamp ]=================================
//=====================================================================================
////Return the timestamp +mm:ss.hh 
char* CGVRguiDlg::GetTimeStamp(void)
{
	char buf[10];
	DWORD mil=GetTickCount()-m_dwTime;	//Get number of milliseconds since last tick
	mil/=10;	//Make it hundreths
	sprintf(&buf[0],"%02i",mil);	
	buf[2]=0; //20170929
	sprintf(&m_czTimeStamp[0],"+%s.%s ",&m_czAsciiTime[0],&buf[0]);

	return &m_czTimeStamp[0];
}

//=====================================================================================
//===================================[ Status ]========================================
//=====================================================================================
//Set the status screen
void CGVRguiDlg::SetStatus(char* Message)
{
	sprintf(&m_czPrintBuffer[0],"%s\n",&Message[0]);
//	Console->Write(CONSOLE_COLOR_WHITE,&m_czPrintBuffer[0]);
	SetDlgItemText(IDC_STATUS,CString(&Message[0]));
	ToLog(&m_czPrintBuffer[0],NO_CONSOLE);
	doWait(200);
}

//=====================================================================================
//===================================[ Status ]========================================
//=====================================================================================
//Set the status screen
void CGVRguiDlg::SetStatus(int Color,char* Message)
{
	sprintf(&m_czPrintBuffer[0],"%s\n",&Message[0]);
	Console->Write(Color,&m_czPrintBuffer[0]);
	Console->Write(CONSOLE_COLOR_WHITE,"\n\n");
	SetDlgItemText(IDC_STATUS,CString(&Message[0]));
	ToLog(&m_czPrintBuffer[0],NO_CONSOLE);
	doWait(200);
}

//Exit
void CGVRguiDlg::OnBnClickedOk()
{
	m_bTestRunning=false;		
	m_iStatus=TEST_EXIT;
	if(m_bCOnChange) WrtINI();	//Save
	Sleep(200);	
	ComPort->Close();			//No serial port
	delete ComPort;
	Printer->Close();			//No printer
	delete Printer;
	Console->Hide();			//No console
	Sleep(200);
	delete Console;

	OnOK();
}

void CGVRguiDlg::ToLog(char* Message, bool ToDisplay)
{
	if(ToDisplay) Console->Write(CONSOLE_COLOR_WHITE,&Message[0]);
	WrtLog(&Message[0]);
}

void CGVRguiDlg::UpdateStatusUser(void)
{
	int i;

	switch(m_iStatus)
	{
		case TEST_PASS:
			SetStatus(CONSOLE_COLOR_GREEN,"** TEST PASSED **\n");
			ShowMessage(MESSAGE_PASS,"");
			if(m_iTested<8) m_iTested++;	//One more
			//Save
			m_iCounts[7]=m_iCounts[6]; m_iCounts[6]=m_iCounts[5];
			m_iCounts[5]=m_iCounts[4]; m_iCounts[4]=m_iCounts[3];
			m_iCounts[3]=m_iCounts[2]; m_iCounts[2]=m_iCounts[1];
			m_iCounts[1]=m_iCounts[0]; m_iCounts[0]=m_iAbsSec;
			//Compute average
			m_iAvSec=0;
			for(i=0;i<8;i++) m_iAvSec+=m_iCounts[i];
			m_iAvSec/=m_iTested;
			//Show
			sprintf(&m_czAsciiTime[0],"%02d:%02d",m_iAvSec/60,m_iAvSec%60);
			SetDlgItemText(IDC_AVERAGE,CString(&m_czAsciiTime[0]));
			break;
		case TEST_FAIL:
			SetStatus(CONSOLE_COLOR_RED,"** TEST FAILED **\n");
			ShowMessage(MESSAGE_FAIL,"");
			break;
		case TEST_FAULT:
			SetStatus(CONSOLE_COLOR_MAGENTA,"** TEST FAULT **\n");
			ShowMessage(MESSAGE_ERROR,"TEST FAULT!");
			break;
		case TEST_STOP:
			SetStatus(CONSOLE_COLOR_RED,"** OPERATOR INTERRUPT **\n");
			ShowMessage(MESSAGE_ERROR,"OPERATOR INTERRUPT!");
			break;
		case TEST_ERROR:
			SetStatus(CONSOLE_COLOR_MAGENTA,"** TEST ERROR **\n");
			ShowMessage(MESSAGE_ERROR,"TEST FAULT!");
			break;
		case TEST_SERIAL:
			SetStatus(CONSOLE_COLOR_RED,"** SERIAL COMMUNICATIONS FAULT **\n");
			ShowMessage(MESSAGE_ERROR,"SERIAL COMMUNICATIONS FAULT!");
			break;
		case TEST_ADMIN:
			SetControls(CONTROLS_OFF);
			GetDlgItem(IDC_STOP)->EnableWindow(false);		//Disable stop
			GetDlgItem(IDOK )->EnableWindow(true);			//Enable Exit
			SetStatus(CONSOLE_COLOR_WHITE,"Plugh!\n\n");
			Beep(500,500);
			SetStatus(CONSOLE_COLOR_RED,"*** ADMINISTRATIVE ACCESS REQUIRED ***\n");
			Beep(500,500);
			SetStatus(CONSOLE_COLOR_WHITE,"*** ADMINISTRATIVE ACCESS REQUIRED ***");
			Beep(500,500);
			SetStatus(CONSOLE_COLOR_BLUE,"*** ADMINISTRATIVE ACCESS REQUIRED ***");
			Beep(500,500);
			SetStatus(CONSOLE_COLOR_GREEN,"*** ADMINISTRATIVE ACCESS REQUIRED ***");
			Beep(500,500);
			SetStatus(CONSOLE_COLOR_YELLOW,"*** ADMINISTRATIVE ACCESS REQUIRED ***");
			Beep(500,500);
			SetStatus(CONSOLE_COLOR_WHITE,"Phred will not permit any software he his responcible for to run without admin rights!\nDo not call Phred, he does not care.\nTake this up with management!");
			Beep(500,500);
			ShowMessage(MESSAGE_ADMIN,"ADMINISTRATIVE ACCESS REQUIRED!\nPLEASE CONTACT YOUR HELP DESK.");
			break;
	}
}

//Start Test
void CGVRguiDlg::OnBnClickedOk2() 
{
	int stateCount=0;
	bool runningResult=true;
	bool localResult=false;
	
	//Save settings
	if(m_bCOnChange) WrtINI();
	Console->Write(CONSOLE_COLOR_GREEN,"** Test Start **\n");
	//Send version
	sprintf_s(&m_czPrintBuffer[0],50,"Test executive: %s\n",&m_czVersion[0]);
	ToLog(&m_czPrintBuffer[0],NO_CONSOLE);
	//Get serial
	m_iStatus=TEST_RUN;
	runningResult=GetSerial();					//Serial
	if(runningResult) 
	{
		Console->Write(CONSOLE_COLOR_WHITE,"Serial Number: ");
		Console->Write(CONSOLE_COLOR_CYAN,&m_czUUTserial[0]);
		Console->Write(CONSOLE_COLOR_WHITE,"\n");
	}

	if(runningResult)	//If Serial
	{
		//Create logs		
		sprintf(&m_czResultLog[0],"./log/result/CCP_%s_%s_%s.log",&m_czUUTserial[0],&m_czIsoTime[0],&m_czStation[0]);
		sprintf(&m_czTapeLog[0],"./log/tape/TapeLog_%s_%s_%s.log",&m_czUUTserial[0],&m_czIsoTime[0],&m_czStation[0]);
		SetControls(CONTROLS_OFF);
		//Begin
		m_bTestRunning=true;
		ClearTime();
		m_bTimer=true;
		ShowMessage(MESSAGE_OK,"Mount the UUT in the fixture");
		//Flush
		m_czDispBuffer[0]=0;
		m_czTapeBuffer[0]=0;
		SetDlgItemText(IDC_RESULT,_T(""));
		WrtTape("----------------------------------------\n",NO_SCREEN,PRINT);
		switch(m_iUUTtype)
		{
			case UUT_TYPE_A001:
				WrtTape("       Model: M15647A001\n",SCREEN,PRINT);
				sprintf(&m_czSetType[0],"A001\r\n");
				break;
			case UUT_TYPE_A002:
				WrtTape("       Model: M15647A002\n",SCREEN,PRINT);
				sprintf(&m_czSetType[0],"A002\r\n");
				break;
		}
		sprintf(&m_czPrintBuffer[0],"      Serial: %s\n",&m_czRawSerial[0]);
		WrtTape(&m_czPrintBuffer[0],SCREEN,PRINT);
		sprintf(&m_czPrintBuffer[0],"   Timestamp: %s\n",&m_czIsoTime[0]);
		WrtTape(&m_czPrintBuffer[0],SCREEN,PRINT);
		sprintf(&m_czPrintBuffer[0],"  Station ID: %s\n",&m_czStation[0]);
		WrtTape(&m_czPrintBuffer[0],NO_SCREEN,PRINT);
		WrtTape("----------------------------------------\n\n",SCREEN,PRINT);
		
		//Let the user know
		Console->Write(CONSOLE_COLOR_WHITE,"\n");
		//Dispatcher
		while(m_bTestRunning)
		{
			switch(++stateCount)
			{
				//----------------------------------------------------------------------------------------
				case TEST_TYPE:	//Set A001,or A002
					SetStatus("Setting device type...");
					ToLog(&m_czSetType[0],false);
					localResult=SendUUT(&m_czSetType[0],"<DONE>",WAIT_6S);
					runningResult=localResult;
					if(!localResult) WrtTape("Communications----------------------FAIL\n",SCREEN,PRINT);
					Console->Write(&m_czPrintBuffer[0]);
					ToLog(&m_czPrintBuffer[0],false);
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_POWER:	//6.1 - Turn the power on
					SetStatus("Power On...");
					ToLog("Send: N\r\n",false);
					localResult=SendUUT("N\r\n","<PASS>",WAIT_2S);
					Console->Write(&m_czPrintBuffer[0]);
					ToLog(&m_czPrintBuffer[0],false);
					runningResult=localResult;
					//Adjust the power off
					if(localResult)
					{
						doWait(200);
						ToLog("Send: Y\r\n",false);
						localResult=SendUUT("Y\r\n","<DONE>",WAIT_2S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
					}
					if(localResult) WrtTape("Power On----------------------------PASS\n",SCREEN,NO_PRINT);
					else 			WrtTape("Power On----------------------------FAIL\n",SCREEN,PRINT);
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_VOLTAGE:	//6.2&6.3 - Check the voltages
					if(m_bTest1)
					{
						SetStatus("Checking voltages...");
						ToLog("Send: V\r\n",false);						
						localResult=SendUUT("V\r\n","<PASS>",WAIT_15S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("Voltages----------------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("Voltages----------------------------FAIL\n",SCREEN,PRINT);
						if(m_bTestRunning==false) continue;
					}
					break;
				//----------------------------------------------------------------------------------------
				case TEST_CURRENT:	//6.4.5 - Overcurrent test
					if(m_bTest2)
					{
						SetStatus("Checking Overcurrent...");
						ToLog("Send: O\r\n",false);
						localResult=SendUUT("O\r\n","<PASS>",WAIT_15S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("Overcurrent Test--------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("Overcurrent Test--------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case PRG_CP2105:	//5.3 - Program U8
					if(m_bTest3)
					{					
						if(m_bCP2105)
						{
							SetStatus("CP2105 Programming...");
							ToLog("Send: P\r\n",false);
							localResult=SendUUT("P\r\n","<DONE>",WAIT_2S);
							Console->Write(&m_czPrintBuffer[0]);
							ToLog(&m_czPrintBuffer[0],false);
							//Prompt the user
							if(localResult) { localResult=DoMessage(PROG_CP2105,"CP2105 Programming","Please program the CP2105, and Click PASS or FAIL"); }
							runningResult=localResult;
							if(localResult) WrtTape("CP2105 Programming------------------PASS\n",SCREEN,NO_PRINT);
							else 			WrtTape("CP2105 Programming------------------FAIL\n",SCREEN,PRINT);
						}
					}
					break;
				//----------------------------------------------------------------------------------------
				case TEST_USB_HUB:	//6.4.1 - Test USB hub enumeration
					if(m_bTest4)
					{
						SetStatus("Checking USB enueration...");
						ToLog("Send: H\r\n",false);
						localResult=SendUUT("H\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("USB Enumeration Test----------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("USB Enumeration Test----------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_DUART:	//6.4.2 - Test DUART 
					if(m_bTest5)
					{
						SetStatus("Checking DUART...");
						ToLog("Send: U\r\n",false);
						localResult=SendUUT("U\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("DUART Test--------------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("DUART Test--------------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_USB:	//6.4.3 - USB Read/Write
					if(m_bTest6)
					{
						SetStatus("Checking USB Read/Write...");
						ToLog("Send: T\r\n",false);
						localResult=SendUUT("T\r\n","<PASS>",WAIT_15S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("USB Read/Write Test-----------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("USB Read/Write Test-----------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_USB_PWR:	//6.4.4 - USB Power
					if(m_bTest7)
					{
						SetStatus("Checking USB Power...");
						ToLog("Send: W\r\n",false);
						localResult=SendUUT("W\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("USB Power Test----------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("USB Power Test----------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case BNA_PORT:	//6.5 - BNA Port Test
					if(m_bTest8)
					{
						SetStatus("Checking BNA Port...");
						ToLog("Send: B\r\n",false);
						localResult=SendUUT("B\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("BNA Port Test-----------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("BNA Port Test-----------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case BNA_VAULT:	//6.6 - BNA Vault Test
					if(m_bTest9)
					{
						SetStatus("Checking BNA Vault...");
						ToLog("Send: J\r\n",false);
						localResult=SendUUT("J\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("BNA Vault Test----------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("BNA Vault Test----------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TRIND_TEST:	//6.7 - TRIND Port Test
					if(m_bTest10)
					{
						SetStatus("Checking TRIND Port...");
						ToLog("Send: I\r\n",false);
						localResult=SendUUT("I\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("TRIND Port Test---------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("TRIND Port Test---------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_CP2105:	//6.8 - CP2105 Control and Status
					if(m_bTest11)
					{
						SetStatus("Checking CP2105...");
						ToLog("Send: C\r\n",false);
						localResult=SendUUT("C\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("CP2105 Test-------------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("CP2105 Test-------------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_PWM:	//6.9 - PWM at P208 (A002 only)
					if(m_iUUTtype==UUT_TYPE_A002)
					{
						if(m_bTest12)
						{
							SetStatus("Checking CP2105...");
							ToLog("Send: M\r\n",false);
							localResult=SendUUT("M\r\n","<PASS>",WAIT_6S);
							Console->Write(&m_czPrintBuffer[0]);
							ToLog(&m_czPrintBuffer[0],false);
							runningResult=localResult;
							if(localResult) WrtTape("PWM Test----------------------------PASS\n",SCREEN,NO_PRINT);
							else 			WrtTape("PWM Test----------------------------FAIL\n",SCREEN,PRINT);
						}	
						if(m_bTestRunning==false) continue;
					}
					break;
				//----------------------------------------------------------------------------------------
				case TEST_BACKLIGHT:	//6.10 - Backlight Enable
					if(m_bTest13)
					{
						SetStatus("Checking Backlight Enable...");
						ToLog("Send: K\r\n",false);
						localResult=SendUUT("K\r\n","<PASS>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("Backlight Test----------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("Backlight Test----------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_RGB:	//6.11 - RGB (A001 only)
					//Fully automated - 20171107
					if(m_iUUTtype==UUT_TYPE_A001)
					{
						if(m_bTest14)
						{
							SetStatus("Checking RGB...");
							ToLog("Send: G\r\n",false);
							localResult=SendUUT("G\r\n","<PASS>",WAIT_2S);
							Console->Write(&m_czPrintBuffer[0]);
							ToLog(&m_czPrintBuffer[0],false);
							runningResult=localResult;
							if(localResult) WrtTape("RGB Test----------------------------PASS\n",SCREEN,NO_PRINT);
							else 			WrtTape("RGB Test----------------------------FAIL\n",SCREEN,PRINT);
						}	
						if(m_bTestRunning==false) continue;
					}
					break;
				//----------------------------------------------------------------------------------------
				case TEST_LVDS:	//6.12 - LVDS (A002 only)
					//Fully automated - 20171107
					if(m_iUUTtype==UUT_TYPE_A002)
					{
						if(m_bTest15)
						{
							SetStatus("Checking LVDS...");
							ToLog("Send: D\r\n",false);
							localResult=SendUUT("D\r\n","<PASS>",WAIT_2S);
							Console->Write(&m_czPrintBuffer[0]);
							ToLog(&m_czPrintBuffer[0],false);
							runningResult=localResult;
							if(localResult) WrtTape("LVDS Test---------------------------PASS\n",SCREEN,NO_PRINT);
							else 			WrtTape("LVDS Test---------------------------FAIL\n",SCREEN,PRINT);
						}	
						if(m_bTestRunning==false) continue;
					}
					break;
				//----------------------------------------------------------------------------------------
				case TEST_AUDIO:	//6.13 - Audio Switching Test
					if(m_bTest16)
					{
						SetStatus("Checking Audio...");
						ToLog("Send: S\r\n",false);
						localResult=SendUUT("S\r\n","<DONE>",WAIT_6S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("Audio Swithing Test-----------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("Audio Swithing Test-----------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_BEEP:	//6.14 - Beeper Test
					//Fully automated - 20171107
					if(m_bTest17)
					{
						SetStatus("Checking Buzzer...");
						ToLog("Send: E\r\n",false);
						localResult=SendUUT("E\r\n","<PASS>",WAIT_2S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("Buzzer Test-------------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("Buzzer Test-------------------------FAIL\n",SCREEN,PRINT);
					}	
					if(m_bTestRunning==false) continue;
					break;
				//----------------------------------------------------------------------------------------
				case TEST_LEDS:	//6.15 - Check the LEDs
					if(m_bTest18)
					{
						SetStatus("Checking LED's...");
						ToLog("Send: L\r\n",false);
						localResult=SendUUT("L\r\n","<PASS>",WAIT_60S);
						Console->Write(&m_czPrintBuffer[0]);
						ToLog(&m_czPrintBuffer[0],false);
						runningResult=localResult;
						if(localResult) WrtTape("LED Test----------------------------PASS\n",SCREEN,NO_PRINT);
						else 			WrtTape("LED Test----------------------------FAIL\n",SCREEN,PRINT);
					}
					if(m_bTestRunning==false) continue;
					break;
					//----------------------------------------------------------------------------------------
				default:	//Done
					m_bTestRunning=false;
					if(runningResult) m_iStatus=TEST_PASS;
					else m_iStatus=TEST_FAULT;
					break;
			} //End case
			doWait(200);	//Interstep delay
			//If quit on fail is enabled, and we have failed, then quit
			if(m_bContFail) { if(runningResult==false) break; }
		} //End while

		//Elapsed time
		m_bTimer=false;
		sprintf(&m_czPrintBuffer[0],"           Test time:  %s\n",&m_czAsciiTime[0]);
		WrtTape(&m_czPrintBuffer[0],NO_SCREEN,PRINT);
		m_bTestRunning=false;
		//Show pass or fail
		if(runningResult==false)
		{
			if(m_iStatus!=TEST_SERIAL) m_iStatus=TEST_FAIL;
			WrtTape("\n          *** TEST FAILED ***\n",SCREEN,PRINT);
		}
		else WrtTape("\n          *** TEST PASSED ***\n",SCREEN,PRINT);
		//Done
		ToLog("Powering OFF...\n",true);
		ToLog("Send: F\r\n",false);						
		SendUUT("F\r\n","<DONE>",WAIT_2S);	//Power off
		ToLog(&m_czPrintBuffer[0],false);
		CloseUUT();							//Close serial port
		SetControls(CONTROLS_ON);
		WrtTape("\n\n\n\n\n\n",NO_SCREEN,PRINT);
		TapeLog();	//log the tape
	}
	else
	{
		m_iStatus=TEST_STOP;	//User skipped serial
		m_bTimer=false;
		ClearTime();
		SetDlgItemText(IDC_TIME,CString(&m_czAsciiTime[0]));
	}
	//Done
	UpdateStatusUser();
	//Update log
	if(runningResult==false)
	{
		//Rename the log
		sprintf(&m_czPrintBuffer[0],"%s.fail",&m_czResultLog[0]);
		rename(&m_czResultLog[0],&m_czPrintBuffer[0]);
	}
	else
	{
		//Rename the log
		sprintf(&m_czPrintBuffer[0],"%s.pass",&m_czResultLog[0]);
		rename(&m_czResultLog[0],&m_czPrintBuffer[0]);	
	}
}

//Stop Test
void CGVRguiDlg::OnBnClickedOk3()
{
	m_bTestRunning=false;
	m_iStatus=TEST_STOP;
}

//Reset fixture (Power off)
void CGVRguiDlg::OnBnClickedOk4()
{
	SendUUT("F\r\n","<DONE>",WAIT_6S);	//Power off
	CloseUUT();						//Close serial port
}

//A001 chosen
void CGVRguiDlg::OnBnClickedRadio1()
{
	m_iUUTtype=UUT_TYPE_A001;
	Console->Write(CONSOLE_COLOR_GRAY,"\n Device Type: ");
	Console->Write(CONSOLE_COLOR_CYAN,"A001");
	Console->Write(CONSOLE_COLOR_GRAY,"\n\n\n");
	if(m_bConfEnable) m_bCOnChange=true;
}

//A002 chosen
void CGVRguiDlg::OnBnClickedRadio3()
{
	m_iUUTtype=UUT_TYPE_A002;
	Console->Write(CONSOLE_COLOR_GRAY,"\n Device Type: ");
	Console->Write(CONSOLE_COLOR_CYAN,"A002");
	Console->Write(CONSOLE_COLOR_GRAY,"\n\n\n");	if(m_bConfEnable) m_bCOnChange=true;}

void CGVRguiDlg::CloseUUT(void)
{
	if(m_bUUTportOpen)
	{
		m_bUUTportOpen=false;
		ComPort->Close();
	}
}

bool CGVRguiDlg::OpenUUT(void)
{
	if(m_bUUTportOpen==false)
	{
		if(ComPort->Open(m_iComPort,9600)) m_bUUTportOpen=true;
		else 
		{
			m_iStatus=TEST_SERIAL;
			return false;
		}
	}
	return true;
}

//=====================================================================================
//===================================[ Send UUT ]======================================
//=====================================================================================
//Send, and wait for answer
bool CGVRguiDlg::SendUUT(char* Message,char* Expect,int Timeout)
{
	bool result=false;
	int count=0;
	int msgPtr=-1;
	unsigned char c;
	bool looking=true;

	//Open port
	if(OpenUUT()==false) return false;
	//Manage the timeout
	if(Timeout<WAIT_2S) Timeout=WAIT_2S;
	Timeout/=50;

	m_czPrintBuffer[0]=0;
	ComPort->Flush();
	ComPort->Write(&Message[0],true);
	while(looking)
	{
		doWait(50);		//Wait
		if((--Timeout)==0)
		{
			ToLog("Message Timeout!\n",CONSOLE);
			m_czPrintBuffer[count]=0;
			return false;
		}
		while(ComPort->Peek())
		{
			if(count>=BUFFER_SIZE)	//20170821
			{
				ToLog("Buffer overrun!\n",CONSOLE);
				m_czPrintBuffer[count]=0;
				return false;
			}
			ComPort->Read(&c,1);
			if(c==0x10) { msgPtr=count; }
			else m_czPrintBuffer[count++]=c;
			if((msgPtr!=-1)&&(c==0x0A)) { looking=false; break; }
		}
	}
	if(msgPtr!=-1)
	{
		if(!memcmp(&m_czPrintBuffer[msgPtr],&Expect[0],6)) { result=true; }
	}
	m_czPrintBuffer[count]=0;

	return result;
}


void CGVRguiDlg::SetControls(int Status)
{
	if(Status)	//Idle mode
	{
		GetDlgItem(IDOK )->EnableWindow(true);			//Enable Exit
		GetDlgItem(IDOK2)->EnableWindow(true);			//Enable Start
		GetDlgItem(IDOK3)->EnableWindow(false);			//Disable Stop
		GetDlgItem(IDOK4)->EnableWindow(true);			//Enable Reset
		GetDlgItem(IDC_RADIO1)->EnableWindow(true);		//Enable Select
		GetDlgItem(IDC_RADIO3)->EnableWindow(true);		//Enable Select
		GetDlgItem(IDC_SERIAL)->EnableWindow(true);		//Enable Port
		GetDlgItem(IDC_PRINTER)->EnableWindow(true);	//Enable Port
		GetDlgItem(IDC_STATION)->EnableWindow(true);	//Enable Station
		GetDlgItem(IDC_CP3105)->EnableWindow(true);		//Enable Check
		GetDlgItem(IDC_STOP)->EnableWindow(true);		//Enable Check	
	}
	else	//Test running
	{
		GetDlgItem(IDOK )->EnableWindow(false);			//Disable Exit
		GetDlgItem(IDOK2)->EnableWindow(false);			//Disable Start
		GetDlgItem(IDOK3)->EnableWindow(true);			//Enable Stop
		GetDlgItem(IDOK4)->EnableWindow(false);			//Disable Reset
		GetDlgItem(IDC_RADIO1)->EnableWindow(false);	//Disable Select
		GetDlgItem(IDC_RADIO3)->EnableWindow(false);	//Disable Select
		GetDlgItem(IDC_SERIAL)->EnableWindow(false);	//Disable Port
		GetDlgItem(IDC_PRINTER)->EnableWindow(false);	//Disable Port
		GetDlgItem(IDC_STATION)->EnableWindow(false);	//Disable Station
		GetDlgItem(IDC_CP3105)->EnableWindow(false);	//Disable Check
		GetDlgItem(IDC_STOP)->EnableWindow(false);		//Disable Check
	}
}

//=====================================================================================
//===================================[ Timer Event ]===================================
//=====================================================================================
//Do timer once every 1000 mS
void CGVRguiDlg::OnTimer(UINT_PTR nIDEvent)
{
	time_t timeGet;
	struct tm *time1;
	int days[]={0,31,59,90,120,151,181,212,243,273,304,334};

	//Get time
	timeGet=time(NULL);
	time1=localtime(&timeGet);
	sprintf(&m_czTime[0],"%04d-%02d-%02d %02d:%02d",(time1->tm_year+1900),time1->tm_mon+1,time1->tm_mday,time1->tm_hour,time1->tm_min);
	sprintf(&m_czIsoTime[0],"%04d%02d%02d%02d%02d%02d",(time1->tm_year+1900),time1->tm_mon+1,time1->tm_mday,time1->tm_hour,time1->tm_min,time1->tm_sec);
	//Tick
	if(m_bTimer)
	{
		m_dwTime=GetTickCount();		//Clear millisecond counter
		m_iAbsSec++;					//Total seconds
		if(m_iAbsSec>6000) m_iAbsSec=0;	//Rollover if more than 100 minuets
		m_iSec++;						//Seconds as partial minuets
		if(m_iSec==60) { m_iSec=0; m_iMin++; if(m_iMin>99) m_iMin=0; }
		sprintf(&m_czAsciiTime[0],"%02d:%02d",m_iMin,m_iSec);
		SetDlgItemText(IDC_TIME,CString(&m_czAsciiTime[0]));
	}	
	else { m_iSec=0; m_iMin=0; }
	
	doEvents();										//Keep UI warm
	CDialog::OnTimer(nIDEvent);
}

//=============================================================================
//============================[ Show INI ]=====================================
//=============================================================================
//Show the INI info
//20170815
void CGVRguiDlg::ShowSetting(void)
{
	Console->Write(CONSOLE_COLOR_WHITE,"--Settings--------");
	//Show the com port
	Console->Write(CONSOLE_COLOR_GRAY,"\n    Com Port: ");
	sprintf(&m_czPrintBuffer[0],"%03i",m_iComPort);
	GetDlgItem(IDC_SERIAL)->SetWindowTextW(CString(&m_czPrintBuffer[0]));
	Console->Write(CONSOLE_COLOR_CYAN,&m_czPrintBuffer[0]);
	//Show the printer port
	Console->Write(CONSOLE_COLOR_GRAY,"\nPrinter Port: ");
	sprintf(&m_czPrintBuffer[0],"%03i",m_iPrinter);
	GetDlgItem(IDC_PRINTER)->SetWindowTextW(CString(&m_czPrintBuffer[0]));
	Console->Write(CONSOLE_COLOR_CYAN,&m_czPrintBuffer[0]);
	//Show the station ID
	Console->Write(CONSOLE_COLOR_GRAY,"\n  Station ID: ");
	Console->Write(CONSOLE_COLOR_CYAN,&m_czStation[0]);
	GetDlgItem(IDC_STATION)->SetWindowTextW(CString(&m_czStation[0]));
	//Show board type
	Console->Write(CONSOLE_COLOR_GRAY,"\n  Board type: ");
	switch(m_iUUTtype)
	{
		case UUT_TYPE_A001: { Console->Write(CONSOLE_COLOR_CYAN,"A001"); break; }
		case UUT_TYPE_A002: { Console->Write(CONSOLE_COLOR_CYAN,"A002"); break; }
	}
	Console->Write(CONSOLE_COLOR_WHITE,"\n------------------\n\n");
}

//=============================================================================
//============================[ Get INI ]======================================
//=============================================================================
//Read the INI file
bool CGVRguiDlg::GetINI(void)
{
	FILE* fp=NULL;
	char buff[100];
	bool result=false;
	//Flush
	//Open INI file (default the values)
	fp=fopen("./ini/PIP3_OMNI.ini","r");
	m_iComPort=84;
	m_iPrinter=1;
	sprintf(&m_czStation[0],"00");
	m_iUUTtype=UUT_TYPE_A001;
	//See if it opened 
	if(fp!=NULL)
	{
		//Read in any order 20170502
		while(!feof(fp))
		{
			fgets(&buff[0],100,fp);
//			fread(&buff[0],1,500,fp);
			if(!memcmp(&buff[0],"ComPort=",8)) m_iComPort=atoi(&buff[8]); 
			if(!memcmp(&buff[0],"Printer=",8)) m_iPrinter=atoi(&buff[8]); 
			if(!memcmp(&buff[0],"Station=",8)) { memcpy(&m_czStation[0],&buff[8],2); m_czStation[2]; }
			if(!memcmp(&buff[0],"MyBoard=",8))
			{
				if(!memcmp(&buff[8],"A001",4)) m_iUUTtype=UUT_TYPE_A001;
				if(!memcmp(&buff[8],"A002",4)) m_iUUTtype=UUT_TYPE_A002;
			}
			if(!memcmp(&buff[0],"Test1=",6))   { if(buff[6]) m_bTest1=true;	  else m_bTest1=false;  }
			if(!memcmp(&buff[0],"Test2=",6))   { if(buff[6]) m_bTest2=true;   else m_bTest2=false;  }
			if(!memcmp(&buff[0],"Test3=",6))   { if(buff[6]) m_bTest3=true;	  else m_bTest3=false;  }
			if(!memcmp(&buff[0],"Test4=",6))   { if(buff[6]) m_bTest4=true;   else m_bTest4=false;  }
			if(!memcmp(&buff[0],"Test5=",6))   { if(buff[6]) m_bTest5=true;   else m_bTest5=false;  }
			if(!memcmp(&buff[0],"Test6=",6))   { if(buff[6]) m_bTest6=true;   else m_bTest6=false;  }
			if(!memcmp(&buff[0],"Test7=",6))   { if(buff[6]) m_bTest7=true;   else m_bTest7=false;  }
			if(!memcmp(&buff[0],"Test8=",6))   { if(buff[6]) m_bTest8=true;   else m_bTest8=false;  }
			if(!memcmp(&buff[0],"Test9=",6))   { if(buff[6]) m_bTest9=true;   else m_bTest9=false;  }
			if(!memcmp(&buff[0],"Test10=",7))  { if(buff[7]) m_bTest10=true;  else m_bTest10=false; }
			if(!memcmp(&buff[0],"Test11=",7))  { if(buff[7]) m_bTest11=true;  else m_bTest11=false; }
			if(!memcmp(&buff[0],"Test12=",7))  { if(buff[7]) m_bTest12=true;  else m_bTest12=false; }
			if(!memcmp(&buff[0],"Test13=",7))  { if(buff[7]) m_bTest13=true;  else m_bTest13=false; }
			if(!memcmp(&buff[0],"Test14=",7))  { if(buff[7]) m_bTest14=true;  else m_bTest14=false; }
			if(!memcmp(&buff[0],"Test15=",7))  { if(buff[7]) m_bTest15=true;  else m_bTest15=false; }
			if(!memcmp(&buff[0],"Test16=",7))  { if(buff[7]) m_bTest16=true;  else m_bTest16=false; }
			if(!memcmp(&buff[0],"Test17=",7))  { if(buff[7]) m_bTest17=true;  else m_bTest17=false; }
			if(!memcmp(&buff[0],"Test18=",7))  { if(buff[7]) m_bTest18=true;  else m_bTest18=false; }

		}
		fclose(fp);
		result=true;
	}
	else
	{
		fp=fopen("./ini/PIP3_OMNI.ini","w");
		//See if it opened 
		if(fp!=NULL)
		{
			fprintf(fp,"ComPort=022\n");
			fprintf(fp,"Printer=001\n");
			fprintf(fp,"Station=00\n");
			fprintf(fp,"MyBoard=A001\n");
			fprintf(fp,"Version=%s\n",m_czVersion);
			fprintf(fp,"Test1=1  - 6.2&6.3 Voltage\n");
			fprintf(fp,"Test2=1  - 6.4.5 Over current\n");
			fprintf(fp,"Test3=1  - 5.3 Program CP2105\n");
			fprintf(fp,"Test4=1  - 6.4.1 USB enumeration\n");
			fprintf(fp,"Test5=1  - 6.4.2 DUART\n");
			fprintf(fp,"Test6=1  - 6.4.3 USB R/W\n");
			fprintf(fp,"Test7=1  - 6.4.4 USB power\n");
			fprintf(fp,"Test8=1 - 6.5 BNA port\n");
			fprintf(fp,"Test9=1 - 6.6 BNA Vault\n");
			fprintf(fp,"Test10=1 - 6.7 TRIND Port\n");
			fprintf(fp,"Test11=1 - 6.8 CP2105\n");
			fprintf(fp,"Test12=1 - 6.9 PWM\n");
			fprintf(fp,"Test13=1 - 6.10 Backlight\n");
			fprintf(fp,"Test14=1 - 6.11 RGB\n");
			fprintf(fp,"Test15=1 - 6.12 LVDS\n");
			fprintf(fp,"Test16=1 - 6.13 Audio\n");
			fprintf(fp,"Test17=1 - 6.14 Beeper\n");
			fprintf(fp,"Test18=1 - 6.15 LED\n");
			fclose(fp);
			result=true;
		}
		else result=false;
	}
	//Show settings
	if(result)
	{
		ShowSetting();
		switch(m_iUUTtype)
		{
			case UUT_TYPE_A001:
				static_cast<CButton*>(GetDlgItem(IDC_RADIO1))->SetCheck(true);
				break;
			case UUT_TYPE_A002:
				static_cast<CButton*>(GetDlgItem(IDC_RADIO3))->SetCheck(true);
				break;
		}
	}
	else Console->Write(CONSOLE_COLOR_RED,"Configuration read failed!");
	
	//Update checkboxes, not saved
	static_cast<CButton*>(GetDlgItem(IDC_CP3105))->SetCheck(true);	//Added 20170830
	static_cast<CButton*>(GetDlgItem(IDC_STOP))->SetCheck(true);
	doWait(100);
	m_bConfEnable=true;

	return result;
}

//=============================================================================
//============================[ Write INI ]====================================
//=============================================================================
//Write the INI file
bool CGVRguiDlg::WrtINI(void)
{
	FILE* fp=NULL;
	bool result=false;

	fp=fopen("./ini/PIP3_OMNI.ini","w");
	//See if it opened 
	if(fp!=NULL)
	{
		fprintf(fp,"ComPort=%03i\n",m_iComPort);
		fprintf(fp,"Printer=%03i\n",m_iPrinter);
		fprintf(fp,"Station=%s\n",&m_czStation[0]);
		//Get type
		switch(m_iUUTtype)
		{
			case UUT_TYPE_A001:
				fprintf(fp,"MyBoard=A001\n");
				break;
			case UUT_TYPE_A002:
				fprintf(fp,"MyBoard=A002\n");
				break;
		}
		fprintf(fp,"Version=%s\n",m_czVersion);
		//EEPROM program
		if(m_bTest1)	fprintf(fp,"Test1=1  - 6.2&6.3 Voltage\n");
		else			fprintf(fp,"Test1=0  - 6.2&6.3 Voltage\n"); 
		//EEPROM program
		if(m_bTest2)	fprintf(fp,"Test2=1  - 6.4.5 Over current\n");
		else			fprintf(fp,"Test2=0  - 6.4.5 Over current\n"); 
		//EEPROM program
		if(m_bTest3)	fprintf(fp,"Test3=1  - 5.3 Program CP2105\n");
		else			fprintf(fp,"Test3=0  - 5.3 Program CP2105\n"); 
		//CPLD program
		if(m_bTest4)	fprintf(fp,"Test4=1  - 6.4.1 USB enumeration\n");
		else			fprintf(fp,"Test4=0  - 6.4.1 USB enumeration\n"); 
		//Qualcomm program
		if(m_bTest5)	fprintf(fp,"Test5=1  - 6.4.2 DUART\n");
		else			fprintf(fp,"Test5=0  - 6.4.2 DUART\n"); 
		//Current source test
		if(m_bTest6)	fprintf(fp,"Test6=1  - 6.4.3 USB R/W\n");
		else			fprintf(fp,"Test6=0  - 6.4.3 USB R/W\n"); 
		//Current loops
		if(m_bTest7)	fprintf(fp,"Test7=1  - 6.4.4 USB power\n");
		else			fprintf(fp,"Test7=0  - 6.4.4 USB power\n"); 
		//MII test
		if(m_bTest8)	fprintf(fp,"Test8=1  - 6.5 BNA port\n");
		else			fprintf(fp,"Test8=0  - 6.5 BNA port\n"); 
		//CPLD tetst
		if(m_bTest9)	fprintf(fp,"Test9=1  - 6.6 BNA Vault\n");
		else			fprintf(fp,"Test9=0  - 6.6 BNA Vault\n"); 
		//Ethernet test
		if(m_bTest10)	fprintf(fp,"Test10=1 - 6.7 TRIND Port\n");
		else			fprintf(fp,"Test10=0 - 6.7 TRIND Port\n"); 
		//Homeplug test
		if(m_bTest11)	fprintf(fp,"Test11=1 - 6.8 CP2105\n");
		else			fprintf(fp,"Test11=0 - 6.8 CP2105\n"); 
		//I2C test
		if(m_bTest12)	fprintf(fp,"Test12=1 - 6.9 PWM\n");
		else			fprintf(fp,"Test12=0 - 6.9 PWM\n"); 
		//SPI test
		if(m_bTest13)	fprintf(fp,"Test13=1 - 6.10 Backlight\n");
		else			fprintf(fp,"Test13=0 - 6.10 Backlight\n"); 
		//SPI test
		if(m_bTest14)	fprintf(fp,"Test14=1 - 6.11 RGB\n");
		else			fprintf(fp,"Test14=0 - 6.11 RGB\n"); 
		//LED test
		if(m_bTest15)	fprintf(fp,"Test15=1 - 6.12 LVDS\n");
		else			fprintf(fp,"Test15=0 - 6.12 LVDS\n"); 
		//USB test
		if(m_bTest16)	fprintf(fp,"Test16=1 - 6.13 Audio\n");
		else			fprintf(fp,"Test16=0 - 6.13 Audio\n"); 
		//Serial test
		if(m_bTest17)	fprintf(fp,"Test17=1 - 6.14 Beeper\n");
		else			fprintf(fp,"Test17=0 - 6.14 Beeper\n"); 
		//GSOM test
		if(m_bTest18)	fprintf(fp,"Test18=1 - 6.15 LED\n");
		else			fprintf(fp,"Test18=0 - 6.15 LED\n"); 
		fclose(fp);
		result=true;
		m_bCOnChange=false;
		ShowSetting();
	}
	else result=false;
	
	return result;
}

void CGVRguiDlg::OnBnClickedCp2105()
{
	m_bCP2105=!m_bCP2105;
	if(m_bCP2105) static_cast<CButton*>(GetDlgItem(IDC_CP3105))->SetCheck(true);
	else static_cast<CButton*>(GetDlgItem(IDC_CP3105))->SetCheck(false);
}

void CGVRguiDlg::OnBnClickedStop()
{
	m_bContFail=!m_bContFail;
	if(m_bQualcomm) static_cast<CButton*>(GetDlgItem(IDC_STOP))->SetCheck(false);
}

void CGVRguiDlg::OnEnChangeSerial()
{
	wchar_t buff[10];

	if(m_bConfEnable)
	{
		GetDlgItem(IDC_SERIAL)->GetWindowText(&buff[0],4);
		wcstombs(&m_czPrintBuffer[0],&buff[0],9);			//Convert from wcat_t to char
		m_iComPort=atoi(&m_czPrintBuffer[0]);
		m_bCOnChange=true;
	}
}

void CGVRguiDlg::OnEnChangePrinter()
{
	wchar_t buff[10];

	if(m_bConfEnable)
	{
		GetDlgItem(IDC_PRINTER)->GetWindowText(&buff[0],4);
		wcstombs(&m_czPrintBuffer[0],&buff[0],9);			//Convert from wcat_t to char
		m_iPrinter=atoi(&m_czPrintBuffer[0]);
		m_bCOnChange=true;
	}
}

void CGVRguiDlg::OnEnChangeStation()
{
	wchar_t buff[10];

	if(m_bConfEnable)
	{
		GetDlgItem(IDC_STATION)->GetWindowText(&buff[0],3);
		wcstombs(&m_czStation[0],&buff[0],9);	//Convert from wcat_t to char
		m_czStation[3]=0;
		m_bCOnChange=true;
	}
}

void CGVRguiDlg::TapeLog(void)
{
	FILE* fp=NULL;

	//Write to log
	fp=fopen(&m_czTapeLog[0],"w");
	if(fp!=NULL)
	{
		fprintf(fp,"%s",&m_czTapeBuffer[0]);
		fclose(fp);
	}
}

void CGVRguiDlg::WrtTape(char* Message,bool Screen,bool Print)
{
	//write to display
	if(Screen)
	{
		strcat(&m_czDispBuffer[0],&Message[0]);
		SetDlgItemText(IDC_RESULT,CString(&m_czDispBuffer[0]));
		WrtLog(&Message[0]);		//Add to result log
	}
	//Write to printer
	if(Print)
	{
		if(m_iPrinter)
		{
			if(m_bPrinterOpen==false) { m_bPrinterOpen=Printer->Open(m_iPrinter,115200); } 
			if(m_bPrinterOpen) Printer->Write(&Message[0]);
		}
		strcat(&m_czTapeBuffer[0],&Message[0]);
	}
}

//=====================================================================================
//===================================[ Fix Serial ]====================================
//=====================================================================================
//Adjust the Serial Number, and zero if not usable
void CGVRguiDlg::fixSerial(void)
{
	char buff[17];
	int len=(int)strlen(&m_czUUTserial[0]);

	sprintf(m_czRawSerial,"%s",&m_czUUTserial[0]);	//Save 20170926
	if(len==0)
	{
		memset(&m_czUUTserial[0],0,17);
		memset(&m_czRawSerial[0],0,17);	//20170926
	}
	else
	{
		if(len<16)
		{
			memset(&buff[0],'0',16);							//Flush
			sprintf(&buff[16-len],"%s",&m_czUUTserial[0]);		//Write
			memcpy(&m_czUUTserial[0],&buff[0],16);				//post back
		}
		m_czUUTserial[16]=0;
	}
	
}

//=====================================================================================
//===================================[ ShowMessage ]===================================
//=====================================================================================
//Show a message of type with text
bool CGVRguiDlg::ShowMessage(int Type,const char* Text)
{
	int result=0;

	CMessage dlg;

	switch(Type)
	{
		case MESSAGE_SERIAL:			//Pass in the buffer	
			dlg.SetMessage(Type,Text,&m_czUUTserial[0]);
			result=(int)dlg.DoModal();	//Do the deed
			if(m_czUUTserial[0]==(char)0xFF) m_iStatus=TEST_STOP;
			else fixSerial();
			break;
		default:						//No buffer needed
			dlg.SetMessage(Type,&Text[0]);
			result=(int)dlg.DoModal();	//Do the deed
			break;
	}
	delete dlg;
	doWait(200);						//Pause - 20170328
	if(result==2) return true;			//OnCancel
	return false;						//OnOK
}

bool CGVRguiDlg::GetSerial(void)
{
	bool result=true;

	m_czUUTserial[0]=0;
	while(1)
	{
		ShowMessage(MESSAGE_SERIAL,&m_czUUTserial[0]);
		if(m_iStatus==TEST_STOP) { result=false; break; }
		if(m_czUUTserial[0]!=0) break;
	}

	return result;
}

bool CGVRguiDlg::checkAdmin(void)
{
    bool result=false;
	FILE* fp=NULL;
	
	//Check token
	result=IsUserAnAdmin();
	
	//Check for the ability to write to root
	if(result)
	{
		fclose(fopen("C:\\Test4adminPlugh.FLG","w"));	//Create
		fp=fopen("C:\\Test4adminPlugh.FLG","w");		//Try to open
		if(fp==NULL) result=false;						//Did it create?
		else
		{
			fclose(fp);									//Done
			DeleteFile(L"C:\\Test4adminPlugh.FLG");
		}
	}
	return result;
}

//=====================================================================================
//===================================[ Log Update ]====================================
//=====================================================================================
//Write to the log
void CGVRguiDlg::WrtLog(char* Text)
{
	FILE* fp;

	fp=fopen(&m_czResultLog[0],"a+");
	if(fp!=NULL)
	{
		fprintf(fp,"%s%s",GetTimeStamp(),&Text[0]);
		fclose(fp);
	}
}

bool CGVRguiDlg::DoMessage(int Pic,char* Caption, char* Message)
{
	bool result=false;
	CTestMessage dlg;
	
	dlg.SetReturn(&result);
	dlg.SetMessage(Pic,&Caption[0],&Message[0]);
	dlg.DoModal();
	delete dlg;
	
	return result;
}
